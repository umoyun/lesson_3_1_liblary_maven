create function change_balance2(real)
    returns TABLE(id integer, first_name character varying, balance real)
    language sql
as
$$
update users set balance = balance * 2 where balance < $1
  returning id, first_name, balance;

$$;

alter function change_balance2(real) owner to postgres;

