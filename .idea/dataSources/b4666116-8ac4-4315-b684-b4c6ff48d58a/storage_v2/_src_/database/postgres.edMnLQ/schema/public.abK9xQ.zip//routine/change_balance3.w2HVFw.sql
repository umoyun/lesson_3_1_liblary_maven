create function change_balance3(real, OUT c1 integer, OUT c2 integer) returns record
    language plpgsql
as
$$
begin
    select count(*) into c1 from users where balance < $1;
  	select count(*) into c2 from users where balance >= $1;
  
  update users set balance = balance * 2 where balance < $1;
  update users set balance = balance * 3 where balance >= $1;

end
$$;

alter function change_balance3(real, out integer, out integer) owner to postgres;

