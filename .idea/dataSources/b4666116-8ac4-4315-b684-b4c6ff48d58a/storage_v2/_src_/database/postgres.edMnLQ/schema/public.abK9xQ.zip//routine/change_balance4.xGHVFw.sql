create procedure change_balance4(IN real)
    language plpgsql
as
$$
begin
  
  update users set balance = balance * 2 where balance < $1;
  commit;
  update users set balance = balance * 3 where balance >= $1;
  rollback;
end
$$;

alter procedure change_balance4(real) owner to postgres;

