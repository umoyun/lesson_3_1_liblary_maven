create function count_users_by_balance(amount real) returns record
    language sql
as
$$
SELECT count(balance) from users WHERE balance > amount * 2
	or balance < amount * 3;


$$;

alter function count_users_by_balance(real) owner to postgres;

