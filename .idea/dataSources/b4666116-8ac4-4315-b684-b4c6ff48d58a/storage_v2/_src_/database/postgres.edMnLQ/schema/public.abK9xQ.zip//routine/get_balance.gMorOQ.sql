create function get_balance(gid integer) returns character varying
    language sql
as
$$
select gender from users where users.id = gid;

$$;

alter function get_balance(integer) owner to postgres;

