create function get_courses_by_student_id(s_id integer)
    returns TABLE(course_name character varying, rating numeric)
    language sql
as
$$
select course.name , rating FROM course, student_course WHERE course.id=student_course.course_id AND
	s_id=student_course.student_id;


$$;

alter function get_courses_by_student_id(integer) owner to postgres;

