create function get_liders_by_student_id(c_id integer)
    returns TABLE(id integer, name character varying, rating integer)
    language sql
as
$$
select DISTINCT student.id, name, rating 
FROM  student, student_course
WHERE student.id IN(
  select student_id 
  FROM student_course
    WHERE student_course.rating IN (select MAX(rating) 
                   FROM student_course 
                   WHERE course_id = c_id)
    AND course_id = c_id)
AND student_course.course_id = c_id 
AND student_course.rating IN (select MAX(rating) 
                   FROM student_course 
                   WHERE course_id = c_id);

$$;

alter function get_liders_by_student_id(integer) owner to postgres;

