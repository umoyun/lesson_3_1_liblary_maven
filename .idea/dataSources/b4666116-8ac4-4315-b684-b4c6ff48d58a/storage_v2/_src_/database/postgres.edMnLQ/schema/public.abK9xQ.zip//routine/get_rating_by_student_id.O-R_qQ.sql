create function get_rating_by_student_id(s_id integer) returns integer
    language sql
as
$$
select AVG(rating) FROM course, student_course WHERE course.id=student_course.course_id AND
	s_id=student_course.student_id;


$$;

alter function get_rating_by_student_id(integer) owner to postgres;

