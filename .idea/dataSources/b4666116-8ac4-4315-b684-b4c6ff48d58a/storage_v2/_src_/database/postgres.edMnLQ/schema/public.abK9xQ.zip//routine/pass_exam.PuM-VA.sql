create function pass_exam(s_id integer, c_id integer, rating_num integer, OUT result character varying) returns character varying
    language sql
as
$$
select completed
  FROM student_course 
  WHERE student_course.student_id = s_id 
  AND student_course.course_id = c_id AND rating >= rating_num ;


$$;

alter function pass_exam(integer, integer, integer, out varchar) owner to postgres;

