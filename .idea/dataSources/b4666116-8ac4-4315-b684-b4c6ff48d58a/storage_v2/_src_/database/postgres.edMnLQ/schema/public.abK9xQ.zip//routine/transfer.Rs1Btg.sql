create function transfer(num1 character varying, num2 character varying, amount real) returns boolean
    language plpgsql
as
$$
begin
	
	UPDATE account set balance = balance - amount where number = num1;
	
	UPDATE account set balance = balance + amount where number = num2;
	
	return true;
end;
$$;

alter function transfer(varchar, varchar, real) owner to postgres;

