create procedure transfer_proc(IN num1 character varying, IN num2 character varying, IN amount real)
    language plpgsql
as
$$
declare 
  b real := 0;
begin

  select balance into b from account where number = num1;
  
  update account set balance = balance - amount where number = num1;

  if b < amount then
    rollback;
  end if;
  -- execute some thing operations
  
  update account set balance = balance + amount where number = num2;
  
rollback;
  
  
  commit;

end;
$$;

alter procedure transfer_proc(varchar, varchar, real) owner to postgres;

